import './style.css'
import { instruments } from './src/data/instruments.js'
import { InstrumentCard } from './src/components/InstrumentCard.js'

document.querySelector('#app').innerHTML = `
  <header class="header">
    <h1>Malik Musical Instruments</h1>
    <p class="subtitle">Quality Instruments for Every Musician</p>
  </header>
  <div class="container">
    ${instruments.map(instrument => InstrumentCard(instrument)).join('')}
  </div>
`;