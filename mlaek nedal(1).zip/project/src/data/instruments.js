export const instruments = [
  {
    id: 1,
    name: 'Classic Guitar',
    image: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=400&h=300&fit=crop',
    price: '$299',
    description: 'Beautiful acoustic guitar with nylon strings'
  },
  {
    id: 2,
    name: 'Grand Piano',
    image: 'https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?w=400&h=300&fit=crop',
    price: '$4,999',
    description: 'Professional concert grand piano'
  },
  {
    id: 3,
    name: 'Violin',
    image: 'https://images.unsplash.com/photo-1612225330812-01a9c6b355ec?w=400&h=300&fit=crop',
    price: '$799',
    description: 'Handcrafted classical violin'
  },
  {
    id: 4,
    name: 'Drum Set',
    image: 'https://images.unsplash.com/photo-1519892300165-cb5542fb47c7?w=400&h=300&fit=crop',
    price: '$1,299',
    description: 'Complete professional drum kit'
  },
  {
    id: 5,
    name: 'Saxophone',
    image: 'https://images.unsplash.com/photo-1573871669414-010dbf73ca84?w=400&h=300&fit=crop',
    price: '$899',
    description: 'Professional alto saxophone'
  },
  {
    id: 6,
    name: 'Electric Guitar',
    image: 'https://images.unsplash.com/photo-1550985616-10810253b84d?w=400&h=300&fit=crop',
    price: '$899',
    description: 'Modern electric guitar with accessories'
  }
];