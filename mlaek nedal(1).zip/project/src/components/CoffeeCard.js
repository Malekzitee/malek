export function CoffeeCard({ name, image }) {
  return `
    <div class="card">
      <img src="${image}" alt="${name}">
      <div class="card-title">${name}</div>
      <a href="#" class="taste-button">Taste</a>
    </div>
  `;
}