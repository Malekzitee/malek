export function InstrumentCard({ name, image, price, description }) {
  return `
    <div class="card">
      <img src="${image}" alt="${name}" class="card-image">
      <div class="card-content">
        <h2 class="card-title">${name}</h2>
        <p class="card-description">${description}</p>
        <div class="card-price">${price}</div>
        <button class="details-button">View Details</button>
      </div>
    </div>
  `;
}